package Payment;

public interface Payment {
    void ProcessPayment();
    void RefundPayment();
}
