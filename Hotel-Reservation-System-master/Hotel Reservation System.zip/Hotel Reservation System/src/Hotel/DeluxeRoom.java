package Hotel;

public class DeluxeRoom extends Room {
    public DeluxeRoom(int room_id, String roomNumber, double price) {
        super(room_id, roomNumber, "Deluxe", price);
    }
}
