package Hotel;

public class StandardRoom extends Room{
    public StandardRoom(int room_id, String roomNumber, double price){
        super(room_id, roomNumber, "Standard", price);
    }
}
