import Database.MySQL_db;
import Hotel.*;
import Menu.*;

public class Main {
    public static void main(String[] args) {
        Main_Menu main_menu = new Main_Menu();
        main_menu.show();

    }
}